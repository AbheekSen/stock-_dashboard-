"""
03_comparative_analysis.py
---------------------------
Performs cross-company and cross-sector analysis:
  - Financial ratio comparison (Tech vs Banking)
  - Correlation matrix of daily returns
  - Sector performance aggregation
  - Ranking tables by return, volatility, and valuation

Outputs a multi-sheet Excel file ready for Power BI import.

Usage:
    python scripts/03_comparative_analysis.py
"""

import pandas as pd
import numpy as np
import sqlite3
import os

# ── Config ────────────────────────────────────────────────────────────────────

DB_PATH   = "data/market_data.db"
IND_FILE  = "outputs/02_indicators.xlsx"
EXCEL_OUT = "outputs/03_comparative_analysis.xlsx"

TICKERS = {
    "Technology": ["TCS.NS", "INFY.NS", "WIPRO.NS", "HCLTECH.NS"],
    "Banking":    ["HDFCBANK.NS", "ICICIBANK.NS", "SBIN.NS", "AXISBANK.NS"],
}

TICKER_NAMES = {
    "TCS.NS":        "TCS",
    "INFY.NS":       "Infosys",
    "WIPRO.NS":      "Wipro",
    "HCLTECH.NS":    "HCL Tech",
    "HDFCBANK.NS":   "HDFC Bank",
    "ICICIBANK.NS":  "ICICI Bank",
    "SBIN.NS":       "SBI",
    "AXISBANK.NS":   "Axis Bank",
}

# ── Load data ─────────────────────────────────────────────────────────────────

def load_fundamentals(db_path):
    conn = sqlite3.connect(db_path)
    df   = pd.read_sql("SELECT * FROM fundamentals", conn)
    conn.close()
    return df


def load_indicators(ind_file):
    return pd.read_excel(ind_file, sheet_name="Indicators_Daily", parse_dates=["date"])


def load_summary(ind_file):
    return pd.read_excel(ind_file, sheet_name="Returns_Summary")


# ── Analysis functions ────────────────────────────────────────────────────────

def sector_lookup():
    rows = []
    for sector, tickers in TICKERS.items():
        for t in tickers:
            rows.append({"ticker": t, "sector": sector, "short_name": TICKER_NAMES.get(t, t)})
    return pd.DataFrame(rows)


def ratio_comparison(fund_df, sector_df):
    """Merge fundamentals with sector labels, clean up for comparison."""
    merged = fund_df.merge(sector_df, on="ticker", how="left")
    cols = [
        "ticker", "short_name", "sector", "company_name",
        "market_cap", "pe_ratio", "pb_ratio", "ev_ebitda",
        "roe", "roa", "debt_to_equity",
        "revenue_growth", "earnings_growth", "dividend_yield",
        "52w_high", "52w_low",
    ]
    available = [c for c in cols if c in merged.columns]
    out = merged[available].copy()

    # Convert ROE / ROA / growth to percentages
    for col in ["roe", "roa", "revenue_growth", "earnings_growth", "dividend_yield"]:
        if col in out.columns:
            out[col] = (out[col] * 100).round(2)

    # Round ratios
    for col in ["pe_ratio", "pb_ratio", "ev_ebitda", "debt_to_equity"]:
        if col in out.columns:
            out[col] = out[col].round(2)

    out["market_cap_cr"] = (out["market_cap"] / 1e7).round(0) if "market_cap" in out.columns else np.nan
    return out


def sector_averages(ratio_df):
    """Average key metrics by sector."""
    numeric_cols = ["pe_ratio", "pb_ratio", "ev_ebitda", "roe", "roa",
                    "debt_to_equity", "revenue_growth", "earnings_growth"]
    available = [c for c in numeric_cols if c in ratio_df.columns]
    if "sector" not in ratio_df.columns:
        ratio_df["sector"] = "Technology"
    return ratio_df.groupby("sector")[available].mean().round(2).reset_index()


def correlation_matrix(indicator_df, sector_df):
    """Daily return correlation matrix across all tickers."""
    pivot = indicator_df.pivot(index="date", columns="ticker", values="daily_return")
    pivot.columns = [TICKER_NAMES.get(c, c) for c in pivot.columns]
    corr = pivot.corr().round(3)
    return corr


def sector_performance(indicator_df, sector_df):
    """Average daily return and volatility per sector over rolling windows."""
    merged = indicator_df.merge(sector_df[["ticker", "sector"]], on="ticker", how="left")
    merged["date"] = pd.to_datetime(merged["date"])

    # Last 1 year
    cutoff_1y = merged["date"].max() - pd.DateOffset(years=1)
    cutoff_3m = merged["date"].max() - pd.DateOffset(months=3)

    def agg(df):
        return df.groupby(["sector", "ticker"]).agg(
            avg_daily_ret=("daily_return", lambda x: x.mean() * 100),
            cum_return=("daily_return", lambda x: ((1 + x).prod() - 1) * 100),
            avg_volatility=("volatility_30d_ann", lambda x: x.mean() * 100),
            avg_rsi=("rsi_14", "mean"),
            avg_beta=("beta_252d", "mean"),
        ).round(3).reset_index()

    perf_1y = agg(merged[merged["date"] >= cutoff_1y])
    perf_3m = agg(merged[merged["date"] >= cutoff_3m])
    perf_1y["period"] = "1Y"
    perf_3m["period"] = "3M"

    perf_1y["short_name"] = perf_1y["ticker"].map(TICKER_NAMES)
    perf_3m["short_name"] = perf_3m["ticker"].map(TICKER_NAMES)

    return pd.concat([perf_1y, perf_3m], ignore_index=True)


def ranking_table(summary_df, sector_df):
    """Rank companies by 1Y return and annotate with sector."""
    merged = summary_df.merge(sector_df[["ticker", "sector", "short_name"]], on="ticker", how="left")
    merged["rank_1y"]  = merged["1y_return_%"].rank(ascending=False).astype(int)
    merged["rank_vol"] = merged["latest_vol_ann"].rank(ascending=True).astype(int)  # lower = safer
    merged["signal"]   = merged["latest_rsi"].apply(
        lambda x: "Overbought (RSI>70)" if x > 70 else ("Oversold (RSI<30)" if x < 30 else "Neutral")
    )
    return merged.sort_values("rank_1y")


# ── Export ────────────────────────────────────────────────────────────────────

def export(ratio_df, sector_avg, corr_df, perf_df, rank_df, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        ratio_df.to_excel(writer,   sheet_name="Financial_Ratios",    index=False)
        sector_avg.to_excel(writer, sheet_name="Sector_Averages",     index=False)
        corr_df.to_excel(writer,    sheet_name="Correlation_Matrix",  index=True)
        perf_df.to_excel(writer,    sheet_name="Sector_Performance",  index=False)
        rank_df.to_excel(writer,    sheet_name="Rankings",            index=False)
    print(f"[OK]   Exported: {path}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    print("=" * 55)
    print("  Stock Dashboard — Step 3: Comparative Analysis")
    print("=" * 55)

    sector_df    = sector_lookup()
    fund_df      = load_fundamentals(DB_PATH)
    indicator_df = load_indicators(IND_FILE)
    summary_df   = load_summary(IND_FILE)

    print("\n[INFO] Building ratio comparison...")
    ratio_df   = ratio_comparison(fund_df, sector_df)
    sector_avg = sector_averages(ratio_df)

    print("[INFO] Building correlation matrix...")
    corr_df = correlation_matrix(indicator_df, sector_df)

    print("[INFO] Building sector performance tables...")
    perf_df = sector_performance(indicator_df, sector_df)

    print("[INFO] Building ranking table...")
    rank_df = ranking_table(summary_df, sector_df)

    export(ratio_df, sector_avg, corr_df, perf_df, rank_df, EXCEL_OUT)

    print("\n[DONE] Comparative analysis complete.")
    print(f"  • Output: {EXCEL_OUT}")
    print("\n── Sector Averages ──")
    print(sector_avg.to_string(index=False))
    print("\n── Rankings ──")
    cols = ["rank_1y", "short_name", "sector", "1y_return_%", "latest_vol_ann", "signal"]
    avail = [c for c in cols if c in rank_df.columns]
    print(rank_df[avail].to_string(index=False))


if __name__ == "__main__":
    main()
