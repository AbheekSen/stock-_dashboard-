"""
04_charts.py
-------------
Generates publication-quality charts for all tickers and saves them to
outputs/charts/. Also creates an HTML interactive report using Plotly.

Charts produced:
  1. Candlestick + Moving Averages (per ticker)
  2. RSI panel (per ticker)
  3. Bollinger Band chart (per ticker)
  4. Sector return comparison (bar chart)
  5. Correlation heatmap
  6. Volatility comparison
  7. Interactive HTML dashboard

Usage:
    python scripts/04_charts.py
"""

import pandas as pd
import numpy as np
import sqlite3
import os

try:
    import plotly.graph_objects as go
    import plotly.express as px
    from plotly.subplots import make_subplots
    import plotly.io as pio
    PLOTLY_OK = True
except ImportError:
    PLOTLY_OK = False
    print("[WARN] plotly not installed. Run: pip install plotly")

try:
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    MPL_OK = True
except ImportError:
    MPL_OK = False
    print("[WARN] matplotlib not installed. Run: pip install matplotlib")

# ── Config ────────────────────────────────────────────────────────────────────

IND_FILE  = "outputs/02_indicators.xlsx"
COMP_FILE = "outputs/03_comparative_analysis.xlsx"
CHART_DIR = "outputs/charts"
HTML_OUT  = "outputs/dashboard.html"

TICKERS = {
    "Technology": ["TCS.NS", "INFY.NS", "WIPRO.NS", "HCLTECH.NS"],
    "Banking":    ["HDFCBANK.NS", "ICICIBANK.NS", "SBIN.NS", "AXISBANK.NS"],
}

TICKER_NAMES = {
    "TCS.NS": "TCS", "INFY.NS": "Infosys", "WIPRO.NS": "Wipro",
    "HCLTECH.NS": "HCL Tech", "HDFCBANK.NS": "HDFC Bank",
    "ICICIBANK.NS": "ICICI Bank", "SBIN.NS": "SBI", "AXISBANK.NS": "Axis Bank",
}

SECTOR_COLORS = {"Technology": "#378ADD", "Banking": "#1D9E75"}

os.makedirs(CHART_DIR, exist_ok=True)

# ── Load data ─────────────────────────────────────────────────────────────────

def load_data():
    ind_df  = pd.read_excel(IND_FILE, sheet_name="Indicators_Daily", parse_dates=["date"])
    summ_df = pd.read_excel(IND_FILE, sheet_name="Returns_Summary")
    corr_df = pd.read_excel(COMP_FILE, sheet_name="Correlation_Matrix", index_col=0)
    perf_df = pd.read_excel(COMP_FILE, sheet_name="Sector_Performance")
    rank_df = pd.read_excel(COMP_FILE, sheet_name="Rankings")
    return ind_df, summ_df, corr_df, perf_df, rank_df


# ── Plotly charts ─────────────────────────────────────────────────────────────

def chart_moving_averages(ticker, df, out_dir):
    """Price + SMA-20/50/200 line chart."""
    t = df[df["ticker"] == ticker].sort_values("date")
    name = TICKER_NAMES.get(ticker, ticker)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=t["date"], y=t["close"],    name="Close",   line=dict(color="#333", width=1.5)))
    fig.add_trace(go.Scatter(x=t["date"], y=t["sma_20"],   name="SMA 20",  line=dict(color="#378ADD", width=1, dash="dot")))
    fig.add_trace(go.Scatter(x=t["date"], y=t["sma_50"],   name="SMA 50",  line=dict(color="#EF9F27", width=1, dash="dot")))
    fig.add_trace(go.Scatter(x=t["date"], y=t["sma_200"],  name="SMA 200", line=dict(color="#E24B4A", width=1.5)))
    fig.update_layout(
        title=f"{name} — Price & Moving Averages",
        xaxis_title="Date", yaxis_title="Price (₹)",
        template="plotly_white", legend=dict(orientation="h", y=-0.15),
        height=450,
    )
    fig.write_html(os.path.join(out_dir, f"{name.replace(' ', '_')}_MA.html"))
    return fig


def chart_bollinger(ticker, df, out_dir):
    """Price + Bollinger Bands."""
    t = df[df["ticker"] == ticker].sort_values("date")
    name = TICKER_NAMES.get(ticker, ticker)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=pd.concat([t["date"], t["date"].iloc[::-1]]),
        y=pd.concat([t["bb_upper"], t["bb_lower"].iloc[::-1]]),
        fill="toself", fillcolor="rgba(55,138,221,0.1)",
        line=dict(color="rgba(0,0,0,0)"), name="BB Band", showlegend=True,
    ))
    fig.add_trace(go.Scatter(x=t["date"], y=t["close"],    name="Close",  line=dict(color="#333", width=1.5)))
    fig.add_trace(go.Scatter(x=t["date"], y=t["bb_upper"], name="Upper",  line=dict(color="#378ADD", width=1, dash="dash")))
    fig.add_trace(go.Scatter(x=t["date"], y=t["bb_mid"],   name="Middle", line=dict(color="#EF9F27", width=1)))
    fig.add_trace(go.Scatter(x=t["date"], y=t["bb_lower"], name="Lower",  line=dict(color="#378ADD", width=1, dash="dash")))
    fig.update_layout(
        title=f"{name} — Bollinger Bands (20-day, 2σ)",
        xaxis_title="Date", yaxis_title="Price (₹)",
        template="plotly_white", height=450,
        legend=dict(orientation="h", y=-0.15),
    )
    fig.write_html(os.path.join(out_dir, f"{name.replace(' ', '_')}_BB.html"))
    return fig


def chart_rsi_macd(ticker, df, out_dir):
    """RSI + MACD subplot."""
    t = df[df["ticker"] == ticker].sort_values("date")
    name = TICKER_NAMES.get(ticker, ticker)

    fig = make_subplots(rows=2, cols=1, shared_xaxes=True,
                        subplot_titles=["RSI (14)", "MACD (12/26/9)"],
                        vertical_spacing=0.08)

    # RSI
    fig.add_trace(go.Scatter(x=t["date"], y=t["rsi_14"], name="RSI", line=dict(color="#7F77DD")), row=1, col=1)
    fig.add_hline(y=70, line_dash="dash", line_color="#E24B4A", row=1, col=1)
    fig.add_hline(y=30, line_dash="dash", line_color="#1D9E75", row=1, col=1)

    # MACD
    fig.add_trace(go.Scatter(x=t["date"], y=t["macd"],        name="MACD",   line=dict(color="#378ADD")), row=2, col=1)
    fig.add_trace(go.Scatter(x=t["date"], y=t["macd_signal"], name="Signal", line=dict(color="#EF9F27")), row=2, col=1)
    colors = ["#1D9E75" if v >= 0 else "#E24B4A" for v in t["macd_hist"]]
    fig.add_trace(go.Bar(x=t["date"], y=t["macd_hist"], name="Histogram", marker_color=colors), row=2, col=1)

    fig.update_layout(title=f"{name} — RSI & MACD", template="plotly_white", height=500,
                      legend=dict(orientation="h", y=-0.1))
    fig.write_html(os.path.join(out_dir, f"{name.replace(' ', '_')}_RSI_MACD.html"))
    return fig


def chart_sector_returns(rank_df, out_dir):
    """Bar chart: 1Y return by company, coloured by sector."""
    if "short_name" not in rank_df.columns or "1y_return_%" not in rank_df.columns:
        return None
    df = rank_df.sort_values("1y_return_%", ascending=True).copy()
    df["sector"] = df["sector"].fillna("Unknown")
    colors = [SECTOR_COLORS.get(s, "#888") for s in df["sector"]]

    fig = go.Figure(go.Bar(
        x=df["1y_return_%"], y=df.get("short_name", df["ticker"]),
        orientation="h", marker_color=colors,
        text=df["1y_return_%"].round(1).astype(str) + "%",
        textposition="outside",
    ))
    # Legend patches
    for sector, color in SECTOR_COLORS.items():
        fig.add_trace(go.Bar(x=[None], y=[None], name=sector, marker_color=color))

    fig.update_layout(
        title="1-Year Return by Company (Tech vs Banking)",
        xaxis_title="Return (%)", template="plotly_white", height=400,
        showlegend=True, legend=dict(orientation="h", y=-0.15),
        barmode="overlay",
    )
    path = os.path.join(out_dir, "sector_returns.html")
    fig.write_html(path)
    return fig


def chart_correlation(corr_df, out_dir):
    """Heatmap of return correlations."""
    labels = [TICKER_NAMES.get(c, c) for c in corr_df.columns]
    fig = go.Figure(go.Heatmap(
        z=corr_df.values, x=labels, y=labels,
        colorscale="RdBu", zmid=0, zmin=-1, zmax=1,
        text=corr_df.values.round(2),
        texttemplate="%{text}", textfont=dict(size=11),
        colorbar=dict(title="Correlation"),
    ))
    fig.update_layout(
        title="Return Correlation Matrix (Daily Returns)",
        template="plotly_white", height=500,
    )
    path = os.path.join(out_dir, "correlation_heatmap.html")
    fig.write_html(path)
    return fig


def chart_volatility(ind_df, out_dir):
    """Line chart of 30-day rolling volatility for all tickers."""
    fig = go.Figure()
    for ticker, grp in ind_df.groupby("ticker"):
        grp = grp.sort_values("date")
        name = TICKER_NAMES.get(ticker, ticker)
        sector = next((s for s, tl in TICKERS.items() if ticker in tl), "Unknown")
        dash = "solid" if sector == "Technology" else "dash"
        fig.add_trace(go.Scatter(
            x=grp["date"], y=(grp["volatility_30d_ann"] * 100).round(2),
            name=name, line=dict(dash=dash, width=1.5),
        ))
    fig.update_layout(
        title="30-Day Rolling Volatility — Annualised (%)",
        xaxis_title="Date", yaxis_title="Volatility (%)",
        template="plotly_white", height=450,
        legend=dict(orientation="h", y=-0.15),
    )
    path = os.path.join(out_dir, "volatility.html")
    fig.write_html(path)
    return fig


# ── HTML dashboard ────────────────────────────────────────────────────────────

def build_html_dashboard(ind_df, summ_df, corr_df, rank_df, out_path):
    """Single-file interactive HTML dashboard."""

    all_tickers = ind_df["ticker"].unique().tolist()
    ticker_opts = "".join(
        f'<option value="{t}">{TICKER_NAMES.get(t, t)}</option>' for t in all_tickers
    )

    # Serialise data as JSON for JS consumption
    import json

    # Price + indicator data per ticker (last 252 trading days)
    ticker_data = {}
    for ticker, grp in ind_df.groupby("ticker"):
        grp = grp.sort_values("date").tail(252)
        ticker_data[ticker] = {
            "dates":   grp["date"].astype(str).tolist(),
            "close":   grp["close"].round(2).tolist(),
            "sma20":   grp["sma_20"].round(2).tolist(),
            "sma50":   grp["sma_50"].round(2).tolist(),
            "sma200":  grp["sma_200"].round(2).tolist(),
            "rsi":     grp["rsi_14"].round(2).tolist(),
            "macd":    grp["macd"].round(3).tolist(),
            "signal":  grp["macd_signal"].round(3).tolist(),
            "bb_up":   grp["bb_upper"].round(2).tolist(),
            "bb_lo":   grp["bb_lower"].round(2).tolist(),
            "vol":     (grp["volatility_30d_ann"] * 100).round(2).tolist(),
        }

    # Summary table rows
    summary_rows = ""
    for _, row in summ_df.iterrows():
        name = TICKER_NAMES.get(row.get("ticker", ""), row.get("ticker", ""))
        sector = next((s for s, tl in TICKERS.items() if row.get("ticker","") in tl), "—")
        ret1y = row.get("1y_return_%", float("nan"))
        vol   = row.get("latest_vol_ann", float("nan"))
        rsi   = row.get("latest_rsi", float("nan"))
        beta  = row.get("latest_beta", float("nan"))

        def fmt(v, suffix=""):
            return f"{v:.2f}{suffix}" if pd.notna(v) else "—"

        rsi_cls = "overbought" if (pd.notna(rsi) and rsi > 70) else ("oversold" if (pd.notna(rsi) and rsi < 30) else "")
        ret_cls = "pos" if (pd.notna(ret1y) and ret1y >= 0) else "neg"

        summary_rows += f"""
        <tr>
          <td><b>{name}</b></td>
          <td>{sector}</td>
          <td>{fmt(row.get('latest_price', float('nan')), '')}</td>
          <td class="{ret_cls}">{fmt(ret1y, "%")}</td>
          <td>{fmt(vol, "%")}</td>
          <td class="{rsi_cls}">{fmt(rsi)}</td>
          <td>{fmt(beta)}</td>
        </tr>"""

    # Correlation table
    corr_labels = [TICKER_NAMES.get(c, c) for c in corr_df.columns]
    corr_header = "".join(f"<th>{l}</th>" for l in corr_labels)
    corr_rows = ""
    for i, row_label in enumerate(corr_labels):
        corr_rows += f"<tr><td><b>{row_label}</b></td>"
        for j, val in enumerate(corr_df.values[i]):
            intensity = int(abs(val) * 200)
            if val > 0:
                bg = f"rgba(55,138,221,{abs(val)*0.6:.2f})"
            else:
                bg = f"rgba(226,75,74,{abs(val)*0.6:.2f})"
            if i == j:
                bg = "#f0f0f0"
            corr_rows += f'<td style="background:{bg};text-align:center">{val:.2f}</td>'
        corr_rows += "</tr>"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Stock Market Analysis Dashboard</title>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          background: #f4f5f7; color: #1a1a1a; }}
  header {{ background: #1a2332; color: white; padding: 18px 32px;
            display: flex; align-items: center; justify-content: space-between; }}
  header h1 {{ font-size: 20px; font-weight: 500; }}
  header span {{ font-size: 13px; opacity: .6; }}
  .main {{ max-width: 1280px; margin: 0 auto; padding: 24px 20px; }}
  .grid2 {{ display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }}
  .grid3 {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 20px; }}
  .card {{ background: white; border-radius: 10px; padding: 20px;
           border: 0.5px solid #e0e0e0; }}
  .card h2 {{ font-size: 14px; font-weight: 500; color: #555; margin-bottom: 14px;
              text-transform: uppercase; letter-spacing: .04em; }}
  .kpi {{ font-size: 28px; font-weight: 600; }}
  .kpi-sub {{ font-size: 13px; color: #888; margin-top: 4px; }}
  .pos {{ color: #1D9E75; }} .neg {{ color: #E24B4A; }}
  .overbought {{ color: #E24B4A; font-weight: 600; }}
  .oversold {{ color: #1D9E75; font-weight: 600; }}
  select, button {{
    padding: 7px 14px; border-radius: 6px; border: 1px solid #ddd;
    font-size: 14px; cursor: pointer; background: white; margin-right: 8px;
  }}
  button.active {{ background: #1a2332; color: white; border-color: #1a2332; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
  th {{ background: #f8f9fa; padding: 9px 12px; text-align: left;
        border-bottom: 1px solid #e0e0e0; font-weight: 500; color: #555; }}
  td {{ padding: 9px 12px; border-bottom: 0.5px solid #f0f0f0; }}
  tr:last-child td {{ border: none; }}
  .controls {{ margin-bottom: 16px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }}
  .tab {{ padding: 6px 16px; border-radius: 6px; border: 1px solid #ddd;
          background: white; cursor: pointer; font-size: 13px; }}
  .tab.active {{ background: #1a2332; color: white; border-color: #1a2332; }}
  .section-title {{ font-size: 17px; font-weight: 500; margin: 24px 0 14px; color: #1a2332; }}
  .full-card {{ background: white; border-radius: 10px; padding: 20px;
                border: 0.5px solid #e0e0e0; margin-bottom: 20px; }}
</style>
</head>
<body>
<header>
  <h1>📈 Stock Market Analysis Dashboard</h1>
  <span id="ts"></span>
</header>
<div class="main">

  <!-- KPI row -->
  <p class="section-title">Overview — Tech &amp; Banking Sectors</p>
  <div class="grid3">
    <div class="card"><h2>Tickers tracked</h2><div class="kpi">8</div><div class="kpi-sub">4 Tech · 4 Banking</div></div>
    <div class="card"><h2>Benchmark</h2><div class="kpi">Nifty 50</div><div class="kpi-sub">^NSEI</div></div>
    <div class="card"><h2>Analysis period</h2><div class="kpi">3 Years</div><div class="kpi-sub">Daily OHLCV data</div></div>
  </div>

  <!-- Summary table -->
  <div class="full-card">
    <h2 style="font-size:14px;font-weight:500;color:#555;text-transform:uppercase;letter-spacing:.04em;margin-bottom:14px;">Company Summary</h2>
    <table>
      <thead><tr>
        <th>Company</th><th>Sector</th><th>Price (₹)</th>
        <th>1Y Return</th><th>Volatility</th><th>RSI-14</th><th>Beta</th>
      </tr></thead>
      <tbody>{summary_rows}</tbody>
    </table>
  </div>

  <!-- Ticker chart -->
  <div class="full-card">
    <h2 style="font-size:14px;font-weight:500;color:#555;text-transform:uppercase;letter-spacing:.04em;margin-bottom:14px;">Technical Analysis</h2>
    <div class="controls">
      <select id="tickerSel">{ticker_opts}</select>
      <button class="tab active" onclick="setChart('price', this)">Price + MAs</button>
      <button class="tab" onclick="setChart('rsi', this)">RSI</button>
      <button class="tab" onclick="setChart('macd', this)">MACD</button>
      <button class="tab" onclick="setChart('bb', this)">Bollinger</button>
      <button class="tab" onclick="setChart('vol', this)">Volatility</button>
    </div>
    <div id="tickerChart" style="height:400px;"></div>
  </div>

  <!-- Correlation -->
  <div class="full-card">
    <h2 style="font-size:14px;font-weight:500;color:#555;text-transform:uppercase;letter-spacing:.04em;margin-bottom:14px;">Return Correlation Matrix</h2>
    <div style="overflow-x:auto;">
      <table style="min-width:500px;">
        <thead><tr><th></th>{corr_header}</tr></thead>
        <tbody>{corr_rows}</tbody>
      </table>
    </div>
  </div>

</div>

<script>
document.getElementById("ts").textContent = "Generated: " + new Date().toLocaleDateString();

const DATA = {json.dumps(ticker_data)};
let currentChart = "price";

function setChart(type, btn) {{
  currentChart = type;
  document.querySelectorAll(".tab").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  renderChart();
}}

function renderChart() {{
  const ticker = document.getElementById("tickerSel").value;
  const d = DATA[ticker];
  if (!d) return;
  const traces = [];
  const layout = {{
    template: "plotly_white",
    margin: {{t:30, r:20, b:50, l:60}},
    legend: {{orientation: "h", y: -0.15}},
    xaxis: {{title: "Date"}},
  }};

  if (currentChart === "price") {{
    traces.push({{x: d.dates, y: d.close, name: "Close", type: "scatter", line: {{color: "#1a2332", width: 2}}}});
    traces.push({{x: d.dates, y: d.sma20,  name: "SMA 20",  type: "scatter", line: {{color: "#378ADD", width: 1, dash: "dot"}}}});
    traces.push({{x: d.dates, y: d.sma50,  name: "SMA 50",  type: "scatter", line: {{color: "#EF9F27", width: 1, dash: "dot"}}}});
    traces.push({{x: d.dates, y: d.sma200, name: "SMA 200", type: "scatter", line: {{color: "#E24B4A", width: 1.5}}}});
    layout.yaxis = {{title: "Price (₹)"}};
  }} else if (currentChart === "rsi") {{
    traces.push({{x: d.dates, y: d.rsi, name: "RSI 14", type: "scatter", line: {{color: "#7F77DD", width: 2}}}});
    layout.shapes = [
      {{type:"line", x0:d.dates[0], x1:d.dates[d.dates.length-1], y0:70, y1:70, line:{{color:"#E24B4A",dash:"dash"}}}},
      {{type:"line", x0:d.dates[0], x1:d.dates[d.dates.length-1], y0:30, y1:30, line:{{color:"#1D9E75",dash:"dash"}}}},
    ];
    layout.yaxis = {{title: "RSI", range: [0, 100]}};
  }} else if (currentChart === "macd") {{
    traces.push({{x: d.dates, y: d.macd,   name: "MACD",   type: "scatter", line: {{color: "#378ADD"}}}});
    traces.push({{x: d.dates, y: d.signal, name: "Signal", type: "scatter", line: {{color: "#EF9F27"}}}});
    layout.yaxis = {{title: "MACD"}};
  }} else if (currentChart === "bb") {{
    traces.push({{x: d.dates, y: d.bb_up, name: "Upper", type: "scatter", line: {{color: "#378ADD", dash:"dash", width:1}}}});
    traces.push({{x: d.dates, y: d.close, name: "Close", type: "scatter", line: {{color: "#1a2332", width: 2}}}});
    traces.push({{x: d.dates, y: d.bb_lo, name: "Lower", type: "scatter", line: {{color: "#378ADD", dash:"dash", width:1}}}});
    layout.yaxis = {{title: "Price (₹)"}};
  }} else if (currentChart === "vol") {{
    traces.push({{x: d.dates, y: d.vol, name: "30d Vol (Ann %)", type: "scatter",
                  fill: "tozeroy", fillcolor: "rgba(55,138,221,0.1)", line: {{color: "#378ADD"}}}});
    layout.yaxis = {{title: "Volatility (%)"}};
  }}

  Plotly.react("tickerChart", traces, layout, {{responsive: true}});
}}

document.getElementById("tickerSel").addEventListener("change", renderChart);
renderChart();
</script>
</body>
</html>"""

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[OK]   Interactive dashboard: {out_path}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    print("=" * 55)
    print("  Stock Dashboard — Step 4: Charts & Dashboard")
    print("=" * 55)

    if not PLOTLY_OK:
        print("[ERROR] Install plotly first: pip install plotly")
        return

    try:
        ind_df, summ_df, corr_df, perf_df, rank_df = load_data()
    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        print("  Run scripts 01–03 first to generate the required Excel files.")
        return

    all_tickers = [t for tl in TICKERS.values() for t in tl]

    print("\n[INFO] Generating per-ticker charts...")
    for ticker in all_tickers:
        name = TICKER_NAMES.get(ticker, ticker)
        chart_moving_averages(ticker, ind_df, CHART_DIR)
        chart_bollinger(ticker, ind_df, CHART_DIR)
        chart_rsi_macd(ticker, ind_df, CHART_DIR)
        print(f"  [OK] {name}")

    print("\n[INFO] Generating comparison charts...")
    chart_sector_returns(rank_df, CHART_DIR)
    chart_correlation(corr_df, CHART_DIR)
    chart_volatility(ind_df, CHART_DIR)

    print("\n[INFO] Building interactive HTML dashboard...")
    build_html_dashboard(ind_df, summ_df, corr_df, rank_df, HTML_OUT)

    print(f"\n[DONE] Charts saved to: {CHART_DIR}/")
    print(f"        Dashboard:         {HTML_OUT}")


if __name__ == "__main__":
    main()
