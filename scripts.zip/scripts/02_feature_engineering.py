"""
02_feature_engineering.py
--------------------------
Reads raw price data from SQLite, computes technical indicators and return
metrics for every ticker, then exports a clean analysis-ready Excel file.

Indicators computed per ticker:
  - Daily / Weekly / Monthly / YTD returns
  - SMA-20, SMA-50, SMA-200
  - EMA-12, EMA-26
  - MACD + Signal line
  - RSI-14
  - Bollinger Bands (20-day, 2σ)
  - 30-day rolling volatility (annualised)
  - Beta vs benchmark (rolling 252-day)

Usage:
    python scripts/02_feature_engineering.py
"""

import pandas as pd
import numpy as np
import sqlite3
import os

# ── Config ────────────────────────────────────────────────────────────────────

DB_PATH    = "data/market_data.db"
EXCEL_OUT  = "outputs/02_indicators.xlsx"
BENCHMARK  = "^NSEI"          # change to "^GSPC" for S&P 500

TICKERS = {
    "Technology": ["TCS.NS", "INFY.NS", "WIPRO.NS", "HCLTECH.NS"],
    "Banking":    ["HDFCBANK.NS", "ICICIBANK.NS", "SBIN.NS", "AXISBANK.NS"],
}

# ── Technical indicator functions ─────────────────────────────────────────────

def sma(series, window):
    return series.rolling(window=window, min_periods=1).mean()

def ema(series, span):
    return series.ewm(span=span, adjust=False).mean()

def rsi(series, period=14):
    delta = series.diff()
    gain  = delta.clip(lower=0).rolling(period).mean()
    loss  = (-delta.clip(upper=0)).rolling(period).mean()
    rs    = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def macd(series, fast=12, slow=26, signal=9):
    ema_fast   = ema(series, fast)
    ema_slow   = ema(series, slow)
    macd_line  = ema_fast - ema_slow
    signal_line = ema(macd_line, signal)
    histogram  = macd_line - signal_line
    return macd_line, signal_line, histogram

def bollinger_bands(series, window=20, num_std=2):
    mid   = sma(series, window)
    std   = series.rolling(window=window, min_periods=1).std()
    upper = mid + num_std * std
    lower = mid - num_std * std
    return upper, mid, lower

def rolling_volatility(returns, window=30, annualise=252):
    return returns.rolling(window=window, min_periods=1).std() * np.sqrt(annualise)

def rolling_beta(stock_returns, bench_returns, window=252):
    def _beta(s, b):
        aligned = pd.concat([s, b], axis=1).dropna()
        if len(aligned) < 10:
            return np.nan
        cov = np.cov(aligned.iloc[:, 0], aligned.iloc[:, 1])[0, 1]
        var = np.var(aligned.iloc[:, 1])
        return cov / var if var != 0 else np.nan

    betas = []
    for i in range(len(stock_returns)):
        start = max(0, i - window + 1)
        b = _beta(stock_returns.iloc[start:i+1], bench_returns.iloc[start:i+1])
        betas.append(b)
    return pd.Series(betas, index=stock_returns.index)


# ── Load data from SQLite ─────────────────────────────────────────────────────

def load_close_prices(db_path, tickers, benchmark):
    conn  = sqlite3.connect(db_path)
    raw   = pd.read_sql("SELECT * FROM prices_raw", conn, parse_dates=["date"])
    conn.close()

    all_syms = tickers + [benchmark]
    close_cols = [f"Close_{s}" for s in all_syms if f"Close_{s}" in raw.columns]
    df = raw[["date"] + close_cols].copy()
    df.set_index("date", inplace=True)
    df.sort_index(inplace=True)
    df.columns = [c.replace("Close_", "") for c in df.columns]
    return df


# ── Build per-ticker indicator frame ─────────────────────────────────────────

def compute_indicators(close_df, tickers, benchmark):
    bench_close   = close_df[benchmark] if benchmark in close_df.columns else None
    bench_returns = bench_close.pct_change() if bench_close is not None else None

    all_frames = []

    for symbol in tickers:
        if symbol not in close_df.columns:
            print(f"  [WARN] {symbol} not found in price data, skipping.")
            continue

        price = close_df[symbol].dropna()
        ret   = price.pct_change()

        # ── Returns ──────────────────────────────────────────────────────
        ytd_start   = price[price.index.year == price.index[-1].year].iloc[0] if len(price) else np.nan
        ytd_return  = (price.iloc[-1] / ytd_start - 1) if not pd.isna(ytd_start) else np.nan

        # ── Moving averages ───────────────────────────────────────────────
        sma20  = sma(price, 20)
        sma50  = sma(price, 50)
        sma200 = sma(price, 200)
        ema12  = ema(price, 12)
        ema26  = ema(price, 26)

        # ── MACD ─────────────────────────────────────────────────────────
        macd_line, signal_line, macd_hist = macd(price)

        # ── RSI ───────────────────────────────────────────────────────────
        rsi14 = rsi(price, 14)

        # ── Bollinger Bands ───────────────────────────────────────────────
        bb_upper, bb_mid, bb_lower = bollinger_bands(price, 20, 2)

        # ── Volatility ────────────────────────────────────────────────────
        vol30 = rolling_volatility(ret, 30)

        # ── Beta ──────────────────────────────────────────────────────────
        if bench_returns is not None:
            beta = rolling_beta(ret.reindex(bench_returns.index), bench_returns)
        else:
            beta = pd.Series(np.nan, index=price.index)

        frame = pd.DataFrame({
            "ticker":       symbol,
            "date":         price.index,
            "close":        price.values,
            "daily_return": ret.values,
            "sma_20":       sma20.values,
            "sma_50":       sma50.values,
            "sma_200":      sma200.values,
            "ema_12":       ema12.values,
            "ema_26":       ema26.values,
            "macd":         macd_line.values,
            "macd_signal":  signal_line.values,
            "macd_hist":    macd_hist.values,
            "rsi_14":       rsi14.values,
            "bb_upper":     bb_upper.values,
            "bb_mid":       bb_mid.values,
            "bb_lower":     bb_lower.values,
            "volatility_30d_ann": vol30.values,
            "beta_252d":    beta.reindex(price.index).values,
        })
        all_frames.append(frame)
        print(f"  [OK] {symbol}")

    combined = pd.concat(all_frames, ignore_index=True)
    combined["date"] = pd.to_datetime(combined["date"]).dt.date
    return combined


# ── Returns summary ───────────────────────────────────────────────────────────

def returns_summary(indicator_df):
    rows = []
    for ticker, grp in indicator_df.groupby("ticker"):
        grp = grp.sort_values("date")
        latest = grp.iloc[-1]["close"]

        def pct_ret(n_days):
            if len(grp) >= n_days:
                base = grp.iloc[-n_days]["close"]
                return (latest / base - 1) * 100 if base else np.nan
            return np.nan

        rows.append({
            "ticker":          ticker,
            "latest_price":    round(latest, 2),
            "1d_return_%":     round(pct_ret(2), 2),
            "1w_return_%":     round(pct_ret(6), 2),
            "1m_return_%":     round(pct_ret(22), 2),
            "3m_return_%":     round(pct_ret(66), 2),
            "6m_return_%":     round(pct_ret(132), 2),
            "1y_return_%":     round(pct_ret(252), 2),
            "latest_rsi":      round(grp.iloc[-1]["rsi_14"], 2),
            "latest_vol_ann":  round(grp.iloc[-1]["volatility_30d_ann"] * 100, 2),
            "latest_beta":     round(grp.iloc[-1]["beta_252d"], 3),
        })
    return pd.DataFrame(rows)


# ── Export ────────────────────────────────────────────────────────────────────

def export(indicator_df, summary_df, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        indicator_df.to_excel(writer, sheet_name="Indicators_Daily", index=False)
        summary_df.to_excel(writer, sheet_name="Returns_Summary", index=False)
    print(f"[OK]   Exported: {path}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    print("=" * 55)
    print("  Stock Dashboard — Step 2: Feature Engineering")
    print("=" * 55)

    all_tickers = [t for sector in TICKERS.values() for t in sector]

    print("\n[INFO] Loading close prices from SQLite...")
    close_df = load_close_prices(DB_PATH, all_tickers, BENCHMARK)

    print(f"\n[INFO] Computing indicators for {len(all_tickers)} tickers...")
    indicator_df = compute_indicators(close_df, all_tickers, BENCHMARK)

    print("\n[INFO] Building returns summary...")
    summary_df = returns_summary(indicator_df)

    export(indicator_df, summary_df, EXCEL_OUT)

    print("\n[DONE] Feature engineering complete.")
    print(f"  • Indicators : {EXCEL_OUT}  (sheet: Indicators_Daily)")
    print(f"  • Summary    : {EXCEL_OUT}  (sheet: Returns_Summary)")
    print(summary_df.to_string(index=False))


if __name__ == "__main__":
    main()
