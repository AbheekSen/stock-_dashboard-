"""
01_data_ingestion.py
--------------------
Fetches OHLCV price data and fundamental ratios for Tech and Banking tickers
using yfinance. Saves raw data to SQLite and exports clean Excel files.

Usage:
    python scripts/01_data_ingestion.py
"""

import yfinance as yf
import pandas as pd
import sqlite3
import os
from datetime import datetime, timedelta

# ── Configuration ────────────────────────────────────────────────────────────

TICKERS = {
    "Technology": ["TCS.NS", "INFY.NS", "WIPRO.NS", "HCLTECH.NS"],
    "Banking":    ["HDFCBANK.NS", "ICICIBANK.NS", "SBIN.NS", "AXISBANK.NS"],
}

# For US stocks, swap above with:
# "Technology": ["AAPL", "MSFT", "GOOGL", "META"],
# "Banking":    ["JPM", "BAC", "GS", "WFC"],

BENCHMARK = "^NSEI"          # Nifty 50  (use "^GSPC" for S&P 500)
START_DATE = (datetime.today() - timedelta(days=3 * 365)).strftime("%Y-%m-%d")
END_DATE   = datetime.today().strftime("%Y-%m-%d")
DB_PATH    = "data/market_data.db"
EXCEL_PATH = "outputs/01_raw_data.xlsx"

# ── Helpers ──────────────────────────────────────────────────────────────────

def get_all_tickers():
    tickers = []
    for sector, symbols in TICKERS.items():
        tickers.extend(symbols)
    return list(set(tickers))


def fetch_price_data(tickers, benchmark, start, end):
    """Download daily OHLCV for all tickers + benchmark."""
    all_symbols = tickers + [benchmark]
    print(f"[INFO] Downloading price data for {len(all_symbols)} symbols...")
    raw = yf.download(all_symbols, start=start, end=end, auto_adjust=True, progress=False)

    # Flatten multi-index columns
    if isinstance(raw.columns, pd.MultiIndex):
        raw.columns = ["_".join(col).strip() for col in raw.columns.values]

    raw.reset_index(inplace=True)
    raw.rename(columns={"Date": "date"}, inplace=True)
    raw["date"] = pd.to_datetime(raw["date"]).dt.date
    print(f"[OK]   Price data shape: {raw.shape}")
    return raw


def fetch_fundamentals(tickers):
    """Pull key financial ratios from yfinance info."""
    records = []
    for symbol in tickers:
        try:
            info = yf.Ticker(symbol).info
            records.append({
                "ticker":            symbol,
                "company_name":      info.get("longName", symbol),
                "sector":            info.get("sector", "Unknown"),
                "market_cap":        info.get("marketCap"),
                "pe_ratio":          info.get("trailingPE"),
                "pb_ratio":          info.get("priceToBook"),
                "ev_ebitda":         info.get("enterpriseToEbitda"),
                "roe":               info.get("returnOnEquity"),
                "roa":               info.get("returnOnAssets"),
                "debt_to_equity":    info.get("debtToEquity"),
                "revenue_growth":    info.get("revenueGrowth"),
                "earnings_growth":   info.get("earningsGrowth"),
                "dividend_yield":    info.get("dividendYield"),
                "52w_high":          info.get("fiftyTwoWeekHigh"),
                "52w_low":           info.get("fiftyTwoWeekLow"),
                "fetched_at":        datetime.now().isoformat(),
            })
            print(f"  [OK] {symbol}")
        except Exception as e:
            print(f"  [WARN] {symbol}: {e}")

    df = pd.DataFrame(records)
    return df


def save_to_sqlite(price_df, fundamentals_df, db_path):
    """Persist data to SQLite for downstream scripts."""
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    price_df.to_sql("prices_raw", conn, if_exists="replace", index=False)
    fundamentals_df.to_sql("fundamentals", conn, if_exists="replace", index=False)
    conn.close()
    print(f"[OK]   Saved to SQLite: {db_path}")


def export_excel(price_df, fundamentals_df, path):
    """Write raw data to Excel for manual inspection."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        price_df.to_excel(writer, sheet_name="Prices_Raw", index=False)
        fundamentals_df.to_excel(writer, sheet_name="Fundamentals", index=False)
    print(f"[OK]   Exported: {path}")


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    print("=" * 55)
    print("  Stock Dashboard — Step 1: Data Ingestion")
    print("=" * 55)

    tickers = get_all_tickers()

    price_df = fetch_price_data(tickers, BENCHMARK, START_DATE, END_DATE)

    print("\n[INFO] Fetching fundamentals (this may take ~30s)...")
    fund_df = fetch_fundamentals(tickers)

    save_to_sqlite(price_df, fund_df, DB_PATH)
    export_excel(price_df, fund_df, EXCEL_PATH)

    print("\n[DONE] Ingestion complete.")
    print(f"  • SQLite DB  : {DB_PATH}")
    print(f"  • Excel file : {EXCEL_PATH}")


if __name__ == "__main__":
    main()
