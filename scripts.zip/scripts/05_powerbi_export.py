"""
05_powerbi_export.py
---------------------
Creates a single, formatted Excel workbook that Power BI can directly
connect to and refresh. All sheets are clean with consistent column
names, proper data types, and no merged cells.

Power BI connection:
  1. Open Power BI Desktop
  2. Get Data → Excel Workbook
  3. Select outputs/powerbi_dataset.xlsx
  4. Load all sheets
  5. In Transform Data, set date columns to Date type
  6. Build your visuals!

Sheets in the output:
  • fact_prices       — daily OHLCV + indicators per ticker
  • fact_returns      — returns summary per ticker
  • dim_company       — company metadata + fundamentals
  • dim_calendar      — date dimension for time-intelligence
  • sector_comparison — sector-level aggregates
  • powerbi_notes     — field descriptions for PBI modeling

Usage:
    python scripts/05_powerbi_export.py
"""

import pandas as pd
import numpy as np
import sqlite3
import os
from datetime import date, timedelta
from openpyxl import load_workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, numbers
)
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule

# ── Config ────────────────────────────────────────────────────────────────────

DB_PATH    = "data/market_data.db"
IND_FILE   = "outputs/02_indicators.xlsx"
COMP_FILE  = "outputs/03_comparative_analysis.xlsx"
OUTPUT     = "outputs/powerbi_dataset.xlsx"

TICKERS = {
    "Technology": ["TCS.NS", "INFY.NS", "WIPRO.NS", "HCLTECH.NS"],
    "Banking":    ["HDFCBANK.NS", "ICICIBANK.NS", "SBIN.NS", "AXISBANK.NS"],
}
TICKER_NAMES = {
    "TCS.NS": "TCS", "INFY.NS": "Infosys", "WIPRO.NS": "Wipro",
    "HCLTECH.NS": "HCL Tech", "HDFCBANK.NS": "HDFC Bank",
    "ICICIBANK.NS": "ICICI Bank", "SBIN.NS": "SBI", "AXISBANK.NS": "Axis Bank",
}

HEADER_FILL  = PatternFill("solid", fgColor="1A2332")
HEADER_FONT  = Font(color="FFFFFF", bold=True, size=11)
ALT_FILL     = PatternFill("solid", fgColor="F8F9FA")
BORDER_THIN  = Border(
    bottom=Side(style="thin", color="E0E0E0"),
    right=Side(style="thin", color="E0E0E0"),
)

# ── Load data ─────────────────────────────────────────────────────────────────

def load_all():
    conn = sqlite3.connect(DB_PATH)
    fund_df = pd.read_sql("SELECT * FROM fundamentals", conn)
    conn.close()

    ind_df   = pd.read_excel(IND_FILE,  sheet_name="Indicators_Daily",  parse_dates=["date"])
    summ_df  = pd.read_excel(IND_FILE,  sheet_name="Returns_Summary")
    perf_df  = pd.read_excel(COMP_FILE, sheet_name="Sector_Performance")
    ratio_df = pd.read_excel(COMP_FILE, sheet_name="Financial_Ratios")
    return fund_df, ind_df, summ_df, perf_df, ratio_df


# ── Build clean fact/dim tables ───────────────────────────────────────────────

def build_fact_prices(ind_df):
    df = ind_df.copy()
    df["date"]        = pd.to_datetime(df["date"])
    df["short_name"]  = df["ticker"].map(TICKER_NAMES)
    df["sector"]      = df["ticker"].apply(
        lambda t: next((s for s, tl in TICKERS.items() if t in tl), "Unknown")
    )
    df["signal_rsi"]  = df["rsi_14"].apply(
        lambda x: "Overbought" if x > 70 else ("Oversold" if x < 30 else "Neutral")
        if pd.notna(x) else "Unknown"
    )
    df["above_sma200"] = (df["close"] > df["sma_200"]).map({True: "Yes", False: "No"})
    df["macd_bullish"] = (df["macd"] > df["macd_signal"]).map({True: "Yes", False: "No"})

    cols = [
        "date", "ticker", "short_name", "sector",
        "close", "daily_return",
        "sma_20", "sma_50", "sma_200",
        "ema_12", "ema_26",
        "macd", "macd_signal", "macd_hist",
        "rsi_14", "signal_rsi",
        "bb_upper", "bb_mid", "bb_lower",
        "volatility_30d_ann", "beta_252d",
        "above_sma200", "macd_bullish",
    ]
    return df[[c for c in cols if c in df.columns]].sort_values(["ticker", "date"])


def build_dim_company(fund_df, summ_df):
    dim = fund_df.copy()
    dim["short_name"] = dim["ticker"].map(TICKER_NAMES)
    dim["sector_label"] = dim["ticker"].apply(
        lambda t: next((s for s, tl in TICKERS.items() if t in tl), dim.loc[dim["ticker"]==t, "sector"].values[0] if len(dim[dim["ticker"]==t]) else "Unknown")
    )
    dim["market_cap_cr"] = (dim["market_cap"] / 1e7).round(0)
    merged = dim.merge(summ_df, on="ticker", how="left")
    cols = [
        "ticker", "short_name", "company_name", "sector_label",
        "market_cap_cr", "pe_ratio", "pb_ratio", "ev_ebitda",
        "roe", "roa", "debt_to_equity",
        "revenue_growth", "earnings_growth", "dividend_yield",
        "52w_high", "52w_low",
        "latest_price", "1y_return_%", "latest_vol_ann", "latest_rsi", "latest_beta",
    ]
    return merged[[c for c in cols if c in merged.columns]]


def build_dim_calendar(start_date, end_date):
    dates = pd.date_range(start=start_date, end=end_date, freq="D")
    df = pd.DataFrame({"date": dates})
    df["year"]          = df["date"].dt.year
    df["quarter"]       = df["date"].dt.quarter
    df["quarter_label"] = "Q" + df["quarter"].astype(str) + " " + df["year"].astype(str)
    df["month"]         = df["date"].dt.month
    df["month_name"]    = df["date"].dt.strftime("%B")
    df["week"]          = df["date"].dt.isocalendar().week.astype(int)
    df["day_of_week"]   = df["date"].dt.dayofweek
    df["weekday_name"]  = df["date"].dt.strftime("%A")
    df["is_weekday"]    = (df["day_of_week"] < 5).map({True: "Yes", False: "No"})
    df["date_key"]      = df["date"].dt.strftime("%Y%m%d").astype(int)
    return df


def build_sector_comparison(perf_df):
    if perf_df is None or perf_df.empty:
        return pd.DataFrame()
    return perf_df.copy()


def build_notes():
    return pd.DataFrame([
        {"sheet": "fact_prices",       "column": "close",              "description": "Adjusted closing price (INR)"},
        {"sheet": "fact_prices",       "column": "daily_return",       "description": "Day-over-day percentage return (decimal, multiply by 100 for %)"},
        {"sheet": "fact_prices",       "column": "sma_20/50/200",      "description": "Simple moving average over 20, 50, 200 trading days"},
        {"sheet": "fact_prices",       "column": "rsi_14",             "description": "RSI oscillator (14-day). >70 overbought, <30 oversold"},
        {"sheet": "fact_prices",       "column": "macd / macd_signal", "description": "MACD (12/26) and 9-day signal line. Bullish when MACD > Signal"},
        {"sheet": "fact_prices",       "column": "bb_upper/lower",     "description": "Bollinger Bands: SMA-20 ± 2 standard deviations"},
        {"sheet": "fact_prices",       "column": "volatility_30d_ann", "description": "30-day rolling std of daily returns, annualised (252 trading days). Multiply by 100 for %"},
        {"sheet": "fact_prices",       "column": "beta_252d",          "description": "252-day rolling beta vs Nifty 50 (^NSEI)"},
        {"sheet": "dim_company",       "column": "roe / roa",          "description": "Return on Equity / Return on Assets (as decimals from yfinance)"},
        {"sheet": "dim_company",       "column": "market_cap_cr",      "description": "Market capitalisation in Indian Crores (1 Cr = 10M INR)"},
        {"sheet": "dim_calendar",      "column": "date_key",           "description": "Integer date key YYYYMMDD for fast joins in Power BI"},
        {"sheet": "sector_comparison", "column": "cum_return",         "description": "Cumulative return over the selected period (decimal, ×100 for %)"},
        {"sheet": "ALL",               "column": "ticker",             "description": "Yahoo Finance ticker symbol (e.g. TCS.NS, HDFCBANK.NS)"},
    ])


# ── Style helpers ─────────────────────────────────────────────────────────────

def style_sheet(ws, df):
    """Apply header styling, alternating rows, auto-width, freeze panes."""
    for col_idx, col_name in enumerate(df.columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for row_idx in range(2, ws.max_row + 1):
        fill = ALT_FILL if row_idx % 2 == 0 else PatternFill()
        for col_idx in range(1, ws.max_column + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            cell.fill = fill
            cell.border = BORDER_THIN
            cell.alignment = Alignment(vertical="center")

    # Auto-width
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            try:
                max_len = max(max_len, len(str(cell.value or "")))
            except Exception:
                pass
        ws.column_dimensions[col_letter].width = min(max_len + 4, 35)

    ws.row_dimensions[1].height = 22
    ws.freeze_panes = "B2"


# ── Export ────────────────────────────────────────────────────────────────────

def export(fact_prices, dim_company, dim_calendar, sector_comp, notes, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with pd.ExcelWriter(path, engine="openpyxl", datetime_format="YYYY-MM-DD") as writer:
        fact_prices.to_excel(writer,  sheet_name="fact_prices",       index=False)
        dim_company.to_excel(writer,  sheet_name="dim_company",       index=False)
        dim_calendar.to_excel(writer, sheet_name="dim_calendar",      index=False)
        sector_comp.to_excel(writer,  sheet_name="sector_comparison", index=False)
        notes.to_excel(writer,        sheet_name="powerbi_notes",     index=False)

    # Apply styling
    wb = load_workbook(path)
    for sheet_name, df in [
        ("fact_prices",       fact_prices),
        ("dim_company",       dim_company),
        ("dim_calendar",      dim_calendar),
        ("sector_comparison", sector_comp),
        ("powerbi_notes",     notes),
    ]:
        if sheet_name in wb.sheetnames:
            style_sheet(wb[sheet_name], df)

    # Conditional formatting on fact_prices → daily_return column
    ws = wb["fact_prices"]
    if "daily_return" in fact_prices.columns:
        ret_col_idx = list(fact_prices.columns).index("daily_return") + 1
        ret_col_letter = get_column_letter(ret_col_idx)
        ws.conditional_formatting.add(
            f"{ret_col_letter}2:{ret_col_letter}{ws.max_row}",
            ColorScaleRule(
                start_type="num", start_value=-0.05, start_color="E24B4A",
                mid_type="num",   mid_value=0,       mid_color="FFFFFF",
                end_type="num",   end_value=0.05,    end_color="1D9E75",
            )
        )

    wb.save(path)
    print(f"[OK]   Exported Power BI dataset: {path}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    print("=" * 55)
    print("  Stock Dashboard — Step 5: Power BI Export")
    print("=" * 55)

    try:
        fund_df, ind_df, summ_df, perf_df, ratio_df = load_all()
    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        print("  Run scripts 01–03 first.")
        return

    print("\n[INFO] Building fact_prices...")
    fact_prices = build_fact_prices(ind_df)

    print("[INFO] Building dim_company...")
    dim_company = build_dim_company(fund_df, summ_df)

    print("[INFO] Building dim_calendar...")
    start = fact_prices["date"].min()
    end   = fact_prices["date"].max()
    dim_calendar = build_dim_calendar(start, end)

    print("[INFO] Building sector comparison...")
    sector_comp = build_sector_comparison(perf_df)

    notes = build_notes()

    export(fact_prices, dim_company, dim_calendar, sector_comp, notes, OUTPUT)

    print("\n[DONE] Power BI dataset ready.")
    print(f"  • File     : {OUTPUT}")
    print(f"  • Rows     : fact_prices={len(fact_prices):,}  dim_company={len(dim_company)}")
    print("\n── Power BI Setup ──")
    print("  1. Open Power BI Desktop")
    print("  2. Get Data → Excel Workbook → select outputs/powerbi_dataset.xlsx")
    print("  3. Load: fact_prices, dim_company, dim_calendar, sector_comparison")
    print("  4. Model view → link fact_prices[ticker] → dim_company[ticker]")
    print("  5.             → link fact_prices[date]  → dim_calendar[date]")
    print("  6. Build visuals! (suggested: line chart, bar chart, matrix, slicer)")


if __name__ == "__main__":
    main()
